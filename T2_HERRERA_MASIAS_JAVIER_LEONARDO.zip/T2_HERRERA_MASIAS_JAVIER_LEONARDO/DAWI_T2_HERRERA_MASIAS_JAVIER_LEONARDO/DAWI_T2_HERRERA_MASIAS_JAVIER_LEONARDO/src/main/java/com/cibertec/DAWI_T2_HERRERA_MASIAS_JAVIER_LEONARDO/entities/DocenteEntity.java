package com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.entities;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@Entity
@Table(name = "docentes")
@NoArgsConstructor
@AllArgsConstructor

public class DocenteEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombres;
    private String apellidos;
    private String correo;
    private String telefono;
    private String especialidad;
    private LocalDate fechaIngreso;
}
