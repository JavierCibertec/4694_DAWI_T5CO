package com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.services;

import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.models.Docente;
import java.util.List;
import java.util.Optional;

public interface IDocenteService {
    List<Docente> listarDocentes();
    Optional<Docente> buscarPorId(Long id);
    Docente registrarDocente(Docente docente);
    Docente actualizarDocente(Long id, Docente docente);
    void eliminarDocente(Long id);
}
