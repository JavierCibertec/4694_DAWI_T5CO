package com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.controllers;

import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.models.Docente;
import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.services.IDocenteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/docentes")
@RequiredArgsConstructor

public class DocenteController {
    private final IDocenteService iDocenteService;

    @PostMapping("/registrar")
    public ResponseEntity<Docente> registrarDocente(@RequestBody @Valid Docente docente) {
        return new ResponseEntity<>(iDocenteService.registrarDocente(docente), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Docente> obtenerDocentePorId(@PathVariable Long id) {
        Optional<Docente> docente = iDocenteService.buscarPorId(id);
        return docente.map(ResponseEntity::ok)
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/all")
    public ResponseEntity<List<Docente>> obtenerDocentes() {
        return ResponseEntity.ok(iDocenteService.listarDocentes());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Docente> actualizarDocente(@PathVariable Long id, @RequestBody @Valid Docente docente) {
        Docente actualizado = iDocenteService.actualizarDocente(id, docente);
        if (actualizado != null) {
            return ResponseEntity.ok(actualizado);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDocente(@PathVariable Long id) {
        Optional<Docente> docente = iDocenteService.buscarPorId(id);
        if (docente.isPresent()) {
            iDocenteService.eliminarDocente(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
