package com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.repositories;

import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.entities.DocenteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface IDocenteRepository extends JpaRepository<DocenteEntity, Long> {
}
