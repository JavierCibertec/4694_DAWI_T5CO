package com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.models;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class Docente {

    private Long id;

    @NotBlank
    @Size(min = 2, max = 100)
    private String nombres;

    @NotBlank
    @Size(min = 2, max = 100)
    private String apellidos;

    @NotBlank
    @Email
    private String correo;

    @Pattern(regexp = "^\\+?[0-9]{7,15}$")
    private String telefono;

    @NotBlank
    private String especialidad;

    private LocalDate fechaIngreso;
}
