package com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.services.implementation;

import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.entities.DocenteEntity;
import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.models.Docente;
import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.repositories.IDocenteRepository;
import com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO.services.IDocenteService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor

public class DocenteService implements IDocenteService {

    private final IDocenteRepository iDocenteRepository;
    private final ObjectMapper objectMapper;

    @Override
    public List<Docente> listarDocentes() {
        return objectMapper.convertValue(iDocenteRepository.findAll(), new TypeReference<List<Docente>>() {});
    }

    @Override
    public Optional<Docente> buscarPorId(Long id) {
        DocenteEntity entity = iDocenteRepository.findById(id).orElse(null);
        if (entity == null) {
            return Optional.empty();
        }
        return Optional.of(objectMapper.convertValue(entity, Docente.class));
    }

    @Override
    public Docente registrarDocente(Docente docente) {
        DocenteEntity docenteEntity = objectMapper.convertValue(docente, DocenteEntity.class);
        DocenteEntity savedEntity = iDocenteRepository.save(docenteEntity);
        return objectMapper.convertValue(savedEntity, Docente.class);
    }

    @Override
    public Docente actualizarDocente(Long id, Docente docente) {
        if (iDocenteRepository.existsById(id)) {
            DocenteEntity docenteEntity = objectMapper.convertValue(docente, DocenteEntity.class);
            docenteEntity.setId(id);
            DocenteEntity updatedEntity = iDocenteRepository.save(docenteEntity);
            return objectMapper.convertValue(updatedEntity, Docente.class);
        }
        return null;
    }

    @Override
    public void eliminarDocente(Long id) {
        iDocenteRepository.deleteById(id);
    }
}
