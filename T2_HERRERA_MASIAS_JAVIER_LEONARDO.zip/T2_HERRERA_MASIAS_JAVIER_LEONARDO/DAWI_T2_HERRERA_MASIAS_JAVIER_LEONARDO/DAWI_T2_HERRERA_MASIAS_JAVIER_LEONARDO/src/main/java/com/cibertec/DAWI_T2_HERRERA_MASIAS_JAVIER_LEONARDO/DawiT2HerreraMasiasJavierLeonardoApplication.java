package com.cibertec.DAWI_T2_HERRERA_MASIAS_JAVIER_LEONARDO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DawiT2HerreraMasiasJavierLeonardoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DawiT2HerreraMasiasJavierLeonardoApplication.class, args);
	}

}
