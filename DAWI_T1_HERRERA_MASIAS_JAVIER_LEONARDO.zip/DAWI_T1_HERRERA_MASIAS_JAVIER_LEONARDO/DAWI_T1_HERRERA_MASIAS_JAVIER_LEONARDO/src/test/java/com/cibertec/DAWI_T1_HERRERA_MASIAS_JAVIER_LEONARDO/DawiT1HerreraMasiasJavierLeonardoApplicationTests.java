package com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawiT1HerreraMasiasJavierLeonardoApplicationTests {

	@Test
	void contextLoads() {
	}

}
