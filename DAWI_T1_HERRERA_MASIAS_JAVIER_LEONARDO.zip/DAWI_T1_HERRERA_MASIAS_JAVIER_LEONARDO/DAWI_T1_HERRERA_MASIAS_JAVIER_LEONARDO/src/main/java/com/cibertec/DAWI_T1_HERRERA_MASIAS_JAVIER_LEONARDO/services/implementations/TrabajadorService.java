package com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.services.implementations;

import com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.models.Trabajador;
import com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.services.ITrabajadorService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TrabajadorService implements ITrabajadorService {

    private final List<Trabajador> listaTrabajadores = new ArrayList<>();
    private long contadorId = 1L;

    public TrabajadorService() {
        // Inicializar con al menos 5 trabajadores de prueba
        listaTrabajadores.add(new Trabajador(contadorId++, "Juan", "Pérez Gómez", "Desarrollador", 3500.0, "Activo"));
        listaTrabajadores.add(new Trabajador(contadorId++, "María", "López Ruiz", "Analista de Sistemas", 4000.0, "Activo"));
        listaTrabajadores.add(new Trabajador(contadorId++, "Carlos", "Ramírez Soto", "Soporte Técnico", 2500.0, "Inactivo"));
        listaTrabajadores.add(new Trabajador(contadorId++, "Ana", "Torres Mendoza", "Jefe de Proyectos", 5500.0, "Activo"));
        listaTrabajadores.add(new Trabajador(contadorId++, "Luis", "Flores Castro", "Tester QA", 2800.0, "Inactivo"));
    }

    @Override
    public List<Trabajador> listarTodos() {
        return listaTrabajadores;
    }

    @Override
    public void guardar(Trabajador trabajador) {
        if (trabajador.getId() == null) {
            // Registro nuevo: Generar ID automáticamente
            trabajador.setId(contadorId++);
            listaTrabajadores.add(trabajador);
        } else {
            // Edición: Actualizar registro existente
            buscarPorId(trabajador.getId()).ifPresent(t -> {
                t.setNombres(trabajador.getNombres());
                t.setApellidos(trabajador.getApellidos());
                t.setCargo(trabajador.getCargo());
                t.setSalario(trabajador.getSalario());
                t.setEstado(trabajador.getEstado());
            });
        }
    }

    @Override
    public Optional<Trabajador> buscarPorId(Long id) {
        return listaTrabajadores.stream().filter(t -> t.getId().equals(id)).findFirst();
    }

    @Override
    public void eliminar(Long id) {
        listaTrabajadores.removeIf(t -> t.getId().equals(id));
    }
}
