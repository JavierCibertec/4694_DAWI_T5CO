package com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.services;

import com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.models.Trabajador;

import java.util.List;
import java.util.Optional;

public interface ITrabajadorService {
    List<Trabajador> listarTodos();
    void guardar(Trabajador trabajador);
    Optional<Trabajador> buscarPorId(Long id);
    void eliminar(Long id);
}
