package com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.controllers;

import com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.models.Trabajador;
import com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.services.ITrabajadorService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/trabajadores")
public class TrabajadorController {

    private final ITrabajadorService ItrabajadorService;



    // Pregunta 03: Listado de trabajadores
    @GetMapping
    public String listarTrabajadores(Model model) {
        model.addAttribute("trabajadores", ItrabajadorService.listarTodos());
        return "listadoApellido"; // Nombre de la vista HTML solicitada
    }

    // Pregunta 02: Formulario de registro
    @GetMapping("/nuevo")
    public String mostrarFormularioRegistro(Model model) {
        model.addAttribute("trabajador", new Trabajador());
        return "registroApellido";
    }

    // Pregunta 02: Formulario de edición
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable Long id, Model model) {
        Trabajador trabajador = ItrabajadorService.buscarPorId(id)
                .orElseThrow(() -> new IllegalArgumentException("ID inválido:" + id));
        model.addAttribute("trabajador", trabajador);
        return "registroApellido";
    }

    // Pregunta 02: Guardar o Actualizar
    @PostMapping("/guardar")
    public String guardarTrabajador(@ModelAttribute Trabajador trabajador) {
        ItrabajadorService.guardar(trabajador);
        return "redirect:/trabajadores";
    }

    // Pregunta 03: Eliminar trabajador
    @GetMapping("/eliminar/{id}")
    public String eliminarTrabajador(@PathVariable Long id) {
        ItrabajadorService.eliminar(id);
        return "redirect:/trabajadores";
    }

}
