package com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DawiT1HerreraMasiasJavierLeonardoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DawiT1HerreraMasiasJavierLeonardoApplication.class, args);
	}

}
