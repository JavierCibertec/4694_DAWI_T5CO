package com.cibertec.DAWI_T1_HERRERA_MASIAS_JAVIER_LEONARDO.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class Trabajador {
    private Long id;
    private String nombres;
    private String apellidos;
    private String cargo;
    private Double salario;
    private String estado; // Activo / Inactivo
}
